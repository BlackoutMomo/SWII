// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getAuth,createUserWithEmailAndPassword,signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js";
import {getFirestore,setDoc, doc} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js"
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDeQj2nE0XxrYu4qvNACectts5Et2eF-Hg",
  authDomain: "blackoutmomo-f01c9.firebaseapp.com",
  databaseURL: "https://blackoutmomo-f01c9-default-rtdb.firebaseio.com",
  projectId: "blackoutmomo-f01c9",
  storageBucket: "blackoutmomo-f01c9.appspot.com",
  messagingSenderId: "97189801897",
  appId: "1:97189801897:web:2a4f1b3237cbdf3a7b1eb8",
  measurementId: "G-JWNQYLC70S"
};
 
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

function showMessage(message,divId){
    var mensageDiv = document.getElementById(divId)
    mensageDiv.style.display='block';
    mensageDiv.innerHTM=message
    mensageDiv.style.opacity=1
    setTimeout(function(){
        mensageDiv.style.opacity=0
    },5000)
}

const signUp=document.getElementById('submitSignUp');
signUp.addEventListener('click', (event) =>{
    event.preventDefault();
    const email=document.getElementById('rEmail').value
    const password=document.getElementById('rPassword').value
    const firstName=document.getElementById('fName').value
    const lastName=document.getElementById('lName').value

    const auth=getAuth();
    const db=getFirestore();

})